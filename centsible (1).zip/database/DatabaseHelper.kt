package com.example.centsible.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "centsible.db"
        private const val DATABASE_VERSION = 1

        // Table names
        private const val TABLE_USERS = "users"
        private const val TABLE_EXPENSES = "expenses"
        private const val TABLE_INCOME = "income"
        private const val TABLE_CATEGORIES = "categories"

        // Common column names
        private const val KEY_ID = "id"
        private const val KEY_CREATED_AT = "created_at"

        // Users Table Columns names
        private const val KEY_NAME = "name"
        private const val KEY_EMAIL = "email"
        private const val KEY_PASSWORD = "password"

        // Expenses Table Columns names
        private const val KEY_AMOUNT = "amount"
        private const val KEY_DESCRIPTION = "description"
        private const val KEY_CATEGORY_ID = "category_id"
        private const val KEY_DATE = "date"

        // Income Table Columns names
        // (similar to expenses, but might have different fields)

        // Categories Table Columns names
        private const val KEY_CATEGORY_NAME = "name"
        private const val KEY_CATEGORY_TYPE = "type"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Creating Users table
        val CREATE_USERS_TABLE = ("CREATE TABLE " + TABLE_USERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
                + KEY_EMAIL + " TEXT UNIQUE," + KEY_PASSWORD + " TEXT,"
                + KEY_CREATED_AT + " DATETIME" + ")")
        db.execSQL(CREATE_USERS_TABLE)

        // Creating Expenses table
        val CREATE_EXPENSES_TABLE = ("CREATE TABLE " + TABLE_EXPENSES + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_AMOUNT + " REAL,"
                + KEY_DESCRIPTION + " TEXT," + KEY_CATEGORY_ID + " INTEGER,"
                + KEY_DATE + " DATE," + KEY_CREATED_AT + " DATETIME" + ")")
        db.execSQL(CREATE_EXPENSES_TABLE)

        // Creating Income table
        val CREATE_INCOME_TABLE = ("CREATE TABLE " + TABLE_INCOME + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_AMOUNT + " REAL,"
                + KEY_DESCRIPTION + " TEXT," + KEY_CATEGORY_ID + " INTEGER,"
                + KEY_DATE + " DATE," + KEY_CREATED_AT + " DATETIME" + ")")
        db.execSQL(CREATE_INCOME_TABLE)

        // Creating Categories table
        val CREATE_CATEGORIES_TABLE = ("CREATE TABLE " + TABLE_CATEGORIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_CATEGORY_NAME + " TEXT,"
                + KEY_CATEGORY_TYPE + " TEXT," + KEY_CREATED_AT + " DATETIME" + ")")
        db.execSQL(CREATE_CATEGORIES_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Drop older tables if existed
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EXPENSES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INCOME")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CATEGORIES")

        // Create tables again
        onCreate(db)
    }
}

