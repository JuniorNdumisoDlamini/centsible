package com.example.centsible.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.centsible.screens.*

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Screen.Welcome.route) {
        composable(Screen.Welcome.route) {
            WelcomeScreen(navController = navController)
        }
        composable(Screen.Login.route) {
            LoginScreen(navController = navController)
        }
        composable(Screen.Register.route) {
            RegisterScreen(navController = navController)
        }
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController)
        }
        composable(Screen.BankingIntegration.route) {
            BankingIntegrationScreen(navController = navController)
        }
        composable(Screen.AddExpense.route) {
            AddExpenseScreen(navController = navController)
        }
        composable(Screen.AddIncome.route) {
            AddIncomeScreen(navController = navController)
        }
        composable(Screen.Categories.route) {
            CategoriesScreen(navController = navController)
        }
        composable(Screen.BudgetGoals.route) {
            BudgetGoalsScreen(navController = navController)
        }
        composable(Screen.ExpenseList.route) {
            ExpenseListScreen(navController = navController)
        }
        composable(Screen.CategoryReport.route) {
            CategoryReportScreen(navController = navController)
        }
        composable(Screen.AIAssistant.route) {
            AIAssistantScreen(navController = navController)
        }
    }
}

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object Login : Screen("login")
    object Register : Screen("register")
    object Profile : Screen("profile")
    object Settings : Screen("settings")
    object BankingIntegration : Screen("banking_integration")
    object AddExpense : Screen("add_expense")
    object AddIncome : Screen("add_income")
    object Categories : Screen("categories")
    object BudgetGoals : Screen("budget_goals")
    object ExpenseList : Screen("expense_list")
    object CategoryReport : Screen("category_report")
    object AIAssistant : Screen("ai_assistant")
}

