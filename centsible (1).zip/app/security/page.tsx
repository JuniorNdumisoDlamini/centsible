"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import { useState } from "react"
import { ArrowLeft, Download } from "lucide-react"

export default function SecurityPage() {
  const [biometricEnabled, setBiometricEnabled] = useState(false)
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Security & Data Management</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Biometric Authentication</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-2">Use your fingerprint or face ID to securely log in to the app.</p>
              <p className="text-sm text-muted-foreground">
                This feature requires a device with biometric capabilities.
              </p>
            </div>
            <Switch checked={biometricEnabled} onCheckedChange={setBiometricEnabled} />
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Data Encryption</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">We use industry-standard encryption to protect your financial data:</p>
          <ul className="list-disc pl-5 space-y-2">
            <li>256-bit AES encryption for data at rest</li>
            <li>TLS 1.3 for data in transit</li>
            <li>End-to-end encryption for sensitive information</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Two-Factor Authentication</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="mb-2">Add an extra layer of security to your account with 2FA.</p>
              <p className="text-sm text-muted-foreground">
                We recommend enabling this feature for optimal account protection.
              </p>
            </div>
            <Switch checked={twoFactorEnabled} onCheckedChange={setTwoFactorEnabled} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Data Export</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Download a copy of your financial data in CSV format:</p>
          <Button>
            <Download className="mr-2 h-4 w-4" />
            Export Data
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

