import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { ArrowLeft, Trophy, Star, TrendingUp } from "lucide-react"

export default function ChallengesPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Budgeting Challenges</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Active Challenges</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-6">
            <ChallengeItem
              title="No-Spend Week"
              description="Avoid non-essential spending for a week"
              progress={3}
              total={7}
              icon={<Star className="h-6 w-6 text-yellow-500" />}
            />
            <ChallengeItem
              title="Savings Boost"
              description="Save 20% of your income this month"
              progress={15}
              total={20}
              icon={<TrendingUp className="h-6 w-6 text-green-500" />}
            />
          </ul>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            <LeaderboardItem name="Sarah T." points={1250} rank={1} />
            <LeaderboardItem name="John D." points={1100} rank={2} />
            <LeaderboardItem name="Emma W." points={950} rank={3} />
            <LeaderboardItem name="You" points={800} rank={4} highlighted />
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Rewards</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Complete challenges and climb the leaderboard to earn amazing rewards!</p>
          <ul className="space-y-4">
            <RewardItem
              title="$50 Cashback"
              description="Top 3 finishers"
              icon={<Trophy className="h-6 w-6 text-yellow-500" />}
            />
            <RewardItem
              title="10% Off Coupon"
              description="Top 10 finishers"
              icon={<Star className="h-6 w-6 text-blue-500" />}
            />
            <RewardItem
              title="Prize Draw Entry"
              description="All participants"
              icon={<TrendingUp className="h-6 w-6 text-green-500" />}
            />
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

function ChallengeItem({ title, description, progress, total, icon }) {
  return (
    <li className="bg-muted p-4 rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center">
          {icon}
          <h3 className="font-semibold ml-2">{title}</h3>
        </div>
        <span className="text-sm font-medium">
          {progress}/{total} days
        </span>
      </div>
      <p className="text-sm text-muted-foreground mb-2">{description}</p>
      <Progress value={(progress / total) * 100} className="h-2" />
    </li>
  )
}

function LeaderboardItem({ name, points, rank, highlighted = false }) {
  return (
    <li className={`flex items-center justify-between p-3 rounded-lg ${highlighted ? "bg-primary/10" : "bg-muted"}`}>
      <div className="flex items-center">
        <span className={`font-bold text-lg mr-3 ${highlighted ? "text-primary" : ""}`}>{rank}</span>
        <span className="font-medium">{name}</span>
      </div>
      <div className="flex items-center">
        <span className="font-semibold mr-2">{points}</span>
        <Trophy className="h-5 w-5 text-yellow-500" />
      </div>
    </li>
  )
}

function RewardItem({ title, description, icon }) {
  return (
    <li className="flex items-center bg-muted p-3 rounded-lg">
      {icon}
      <div className="ml-3">
        <h4 className="font-semibold">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </li>
  )
}

