import ProfileScreen from "@/components/profile-screen"

export default function ProfilePage() {
  return <ProfileScreen />
}

