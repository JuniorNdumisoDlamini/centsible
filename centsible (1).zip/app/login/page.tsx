import LoginScreen from "@/components/login-screen"

export default function LoginPage() {
  return <LoginScreen />
}

