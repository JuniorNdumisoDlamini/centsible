import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, MapPin, Camera, Bell } from "lucide-react"

export default function MobileFeaturesPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Mobile-Specific Features</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Location-Based Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Automatically tag your expenses with location data for better tracking:</p>
          <div className="bg-muted p-4 rounded-md mb-4">
            <div className="flex items-center mb-2">
              <MapPin className="mr-2 h-4 w-4" />
              <span className="font-semibold">Grocery Store</span>
            </div>
            <p className="text-sm text-muted-foreground">$75.50 - June 15, 2023</p>
          </div>
          <Button>
            <MapPin className="mr-2 h-4 w-4" />
            Enable Location Tracking
          </Button>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Receipt Scanning</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Quickly capture and process receipts using your device's camera:</p>
          <div className="bg-muted p-4 rounded-md mb-4 flex items-center justify-center">
            <Camera className="h-12 w-12 text-muted-foreground" />
          </div>
          <Button>
            <Camera className="mr-2 h-4 w-4" />
            Scan Receipt
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Push Notifications</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Stay on top of your finances with timely alerts and reminders:</p>
          <ul className="space-y-2 mb-4">
            <li>🚨 Approaching budget limits</li>
            <li>💰 Bill payment reminders</li>
            <li>🎉 Savings goal achievements</li>
          </ul>
          <Button>
            <Bell className="mr-2 h-4 w-4" />
            Manage Notifications
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

