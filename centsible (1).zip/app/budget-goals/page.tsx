"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function BudgetGoalsPage() {
  const [minGoal, setMinGoal] = useState("")
  const [maxGoal, setMaxGoal] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send this data to your backend
    console.log({ minGoal, maxGoal })
    // Show confirmation or navigate to another page
  }

  return (
    <div className="container max-w-md mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Budget Goals</h1>
      </div>

      <form onSubmit={handleSubmit}>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Set Monthly Goals</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label htmlFor="minGoal" className="block text-sm font-medium text-muted-foreground mb-1">
                Minimum Goal ($)
              </label>
              <Input
                id="minGoal"
                type="number"
                placeholder="0.00"
                value={minGoal}
                onChange={(e) => setMinGoal(e.target.value)}
                required
              />
            </div>
            <div>
              <label htmlFor="maxGoal" className="block text-sm font-medium text-muted-foreground mb-1">
                Maximum Goal ($)
              </label>
              <Input
                id="maxGoal"
                type="number"
                placeholder="0.00"
                value={maxGoal}
                onChange={(e) => setMaxGoal(e.target.value)}
                required
              />
            </div>
          </CardContent>
        </Card>
        <Button type="submit" className="w-full">
          Set Goals
        </Button>
      </form>
    </div>
  )
}

