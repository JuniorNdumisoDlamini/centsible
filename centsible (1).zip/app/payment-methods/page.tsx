"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { ArrowLeft, CreditCard, Trash2 } from "lucide-react"

export default function PaymentMethodsPage() {
  const [cards, setCards] = useState([
    { id: 1, last4: "1234", expiry: "12/24", type: "Visa" },
    { id: 2, last4: "5678", expiry: "06/25", type: "Mastercard" },
  ])

  const [newCard, setNewCard] = useState({
    number: "",
    expiry: "",
    cvc: "",
    name: "",
  })

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send this data to your backend
    console.log("Adding new card:", newCard)
    // Add the new card to the list (in a real app, you'd get the ID from the backend)
    setCards([...cards, { id: Date.now(), last4: newCard.number.slice(-4), expiry: newCard.expiry, type: "New Card" }])
    // Reset the form
    setNewCard({ number: "", expiry: "", cvc: "", name: "" })
  }

  const handleRemoveCard = (id: number) => {
    // Here you would typically send a request to your backend to remove the card
    setCards(cards.filter((card) => card.id !== id))
  }

  return (
    <div className="container max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Payment Methods</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Your Cards</CardTitle>
        </CardHeader>
        <CardContent>
          {cards.map((card) => (
            <div key={card.id} className="flex items-center justify-between p-4 bg-muted rounded-lg mb-4">
              <div className="flex items-center">
                <CreditCard className="h-6 w-6 mr-4" />
                <div>
                  <p className="font-medium">
                    {card.type} ending in {card.last4}
                  </p>
                  <p className="text-sm text-muted-foreground">Expires {card.expiry}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => handleRemoveCard(card.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add New Card</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddCard} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input
                id="cardNumber"
                value={newCard.number}
                onChange={(e) => setNewCard({ ...newCard, number: e.target.value })}
                placeholder="1234 5678 9012 3456"
                required
              />
            </div>
            <div className="flex space-x-4">
              <div className="flex-1 space-y-2">
                <Label htmlFor="expiry">Expiry Date</Label>
                <Input
                  id="expiry"
                  value={newCard.expiry}
                  onChange={(e) => setNewCard({ ...newCard, expiry: e.target.value })}
                  placeholder="MM/YY"
                  required
                />
              </div>
              <div className="flex-1 space-y-2">
                <Label htmlFor="cvc">CVC</Label>
                <Input
                  id="cvc"
                  value={newCard.cvc}
                  onChange={(e) => setNewCard({ ...newCard, cvc: e.target.value })}
                  placeholder="123"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Name on Card</Label>
              <Input
                id="name"
                value={newCard.name}
                onChange={(e) => setNewCard({ ...newCard, name: e.target.value })}
                placeholder="John Doe"
                required
              />
            </div>
            <Button type="submit" className="w-full">
              Add Card
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

