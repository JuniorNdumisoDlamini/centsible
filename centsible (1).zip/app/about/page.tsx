import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">About Centsible</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Our Mission</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            At Centsible, our mission is to empower individuals to take control of their financial lives. We believe
            that everyone deserves access to powerful, easy-to-use tools that can help them budget, save, and achieve
            their financial goals.
          </p>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Our Story</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            Centsible was founded in 2023 by a group of finance experts and tech enthusiasts who saw a need for a more
            intuitive, user-friendly budgeting app. Our team combines years of experience in personal finance, machine
            learning, and user experience design to create a tool that's both powerful and accessible.
          </p>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Our Values</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Simplicity: We believe financial management should be straightforward and stress-free.</li>
            <li>Security: Your financial data is sensitive, and we treat it with the utmost care and protection.</li>
            <li>Innovation: We're constantly exploring new ways to make budgeting more effective and engaging.</li>
            <li>Education: We're committed to improving financial literacy through our app and resources.</li>
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Meet the Team</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <img src="/placeholder.svg?height=100&width=100" alt="Jane Doe" className="rounded-full mx-auto mb-2" />
              <h3 className="font-semibold">Jane Doe</h3>
              <p className="text-sm text-muted-foreground">CEO & Co-founder</p>
            </div>
            <div className="text-center">
              <img src="/placeholder.svg?height=100&width=100" alt="John Smith" className="rounded-full mx-auto mb-2" />
              <h3 className="font-semibold">John Smith</h3>
              <p className="text-sm text-muted-foreground">CTO & Co-founder</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

