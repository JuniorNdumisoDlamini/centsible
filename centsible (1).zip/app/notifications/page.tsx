"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, Bell } from "lucide-react"

type Notification = {
  id: number
  message: string
  type: "info" | "warning" | "success"
  timestamp: Date
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    // Simulating fetching notifications from an API
    const fetchedNotifications: Notification[] = [
      {
        id: 1,
        message: "You're approaching your budget limit for dining out.",
        type: "warning",
        timestamp: new Date(),
      },
      {
        id: 2,
        message: "Congratulations! You've reached your savings goal.",
        type: "success",
        timestamp: new Date(Date.now() - 86400000),
      },
      {
        id: 3,
        message: "New budgeting tip available. Check it out!",
        type: "info",
        timestamp: new Date(Date.now() - 172800000),
      },
    ]
    setNotifications(fetchedNotifications)
  }, [])

  const handleNotificationClick = (id: number) => {
    // Mark notification as read
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
    // Here you would typically handle the notification action, e.g., navigate to a specific page
  }

  return (
    <div className="container max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Notifications</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Notifications</CardTitle>
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <p>No new notifications</p>
          ) : (
            <ul className="space-y-4">
              {notifications.map((notification) => (
                <li key={notification.id} className="p-4 bg-muted rounded-lg">
                  <div className="flex items-start">
                    <Bell
                      className={`h-5 w-5 mr-2 ${
                        notification.type === "warning"
                          ? "text-yellow-500"
                          : notification.type === "success"
                            ? "text-green-500"
                            : "text-blue-500"
                      }`}
                    />
                    <div>
                      <p className="font-medium">{notification.message}</p>
                      <p className="text-sm text-muted-foreground">{notification.timestamp.toLocaleString()}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

