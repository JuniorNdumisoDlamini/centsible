import WelcomeScreen from "@/components/welcome-screen"

export default function Home() {
  return <WelcomeScreen />
}

