"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import Link from "next/link"
import { ArrowLeft, Send } from "lucide-react"

type Message = {
  role: "user" | "assistant"
  content: string
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your Centsible AI assistant. How can I help you manage your finances today?",
    },
  ])
  const [input, setInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const handleSend = () => {
    if (input.trim()) {
      setMessages([...messages, { role: "user", content: input }])
      // In a real app, you'd send this to your AI service and get a response
      setTimeout(() => {
        setMessages((prev) => [...prev, { role: "assistant", content: getAIResponse(input) }])
      }, 1000)
      setInput("")
    }
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  return (
    <div className="container max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">AI Assistant</h1>
      </div>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Chat with Your Financial AI</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] mb-4 p-4">
            {messages.map((message, index) => (
              <div key={index} className={`mb-4 ${message.role === "user" ? "text-right" : "text-left"}`}>
                <div
                  className={`inline-block p-3 rounded-lg ${message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}
                >
                  {message.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </ScrollArea>
          <div className="flex space-x-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your finances..."
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
            />
            <Button onClick={handleSend}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>What Can I Do?</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Add expenses or income</li>
            <li>Set financial goals</li>
            <li>Categorize transactions</li>
            <li>Generate reports for specific date ranges</li>
            <li>Provide budgeting advice</li>
            <li>Answer questions about your finances</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

function getAIResponse(input: string): string {
  // This is a simple mock-up. In a real app, you'd use a proper NLP model.
  if (input.toLowerCase().includes("add expense")) {
    return "Sure, I can help you add an expense. What's the amount and category?"
  } else if (input.toLowerCase().includes("set goal")) {
    return "Great! Setting financial goals is important. What kind of goal would you like to set?"
  } else if (input.toLowerCase().includes("report")) {
    return "I'd be happy to generate a report for you. What date range would you like to see?"
  } else {
    return "I'm sorry, I didn't quite understand that. Could you please rephrase your request?"
  }
}

