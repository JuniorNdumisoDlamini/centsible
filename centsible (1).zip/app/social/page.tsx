import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { ArrowLeft, Users, Share2, MessageSquare } from "lucide-react"

export default function SocialPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold">Social Features</h1>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Budgeting Buddies</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Connect with friends to stay accountable and motivate each other:</p>
          <div className="flex space-x-2 mb-4">
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Sarah" />
              <AvatarFallback>ST</AvatarFallback>
            </Avatar>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="John" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Emma" />
              <AvatarFallback>EW</AvatarFallback>
            </Avatar>
          </div>
          <Button>
            <Users className="mr-2 h-4 w-4" />
            Find Buddies
          </Button>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Social Sharing</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Share your financial milestones and achievements on social media:</p>
          <div className="bg-muted p-4 rounded-md mb-4">
            <p className="font-semibold">🎉 I just reached my savings goal of $5000!</p>
            <p className="text-sm text-muted-foreground">Achieved with Centsible app</p>
          </div>
          <Button>
            <Share2 className="mr-2 h-4 w-4" />
            Share Achievement
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Community Forum</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Join discussions, share tips, and learn from other users:</p>
          <ul className="space-y-2 mb-4">
            <li>📌 Tips for reducing grocery expenses</li>
            <li>💡 Creative ways to earn extra income</li>
            <li>🏠 Saving strategies for first-time home buyers</li>
          </ul>
          <Button>
            <MessageSquare className="mr-2 h-4 w-4" />
            Visit Forum
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

