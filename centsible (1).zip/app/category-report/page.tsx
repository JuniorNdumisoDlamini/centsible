"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { ArrowLeft, Calendar } from "lucide-react"
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "@/components/ui/chart"

// Mock data for category spending
const mockCategorySpending = [
  { category: "Groceries", amount: 350.75, color: "#FF6384" },
  { category: "Transportation", amount: 120.0, color: "#36A2EB" },
  { category: "Entertainment", amount: 85.5, color: "#FFCE56" },
  { category: "Utilities", amount: 200.0, color: "#4BC0C0" },
  { category: "Dining Out", amount: 150.25, color: "#9966FF" },
  { category: "Shopping", amount: 75.8, color: "#FF9F40" },
]

export default function CategoryReportPage() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [categorySpending, setCategorySpending] = useState(mockCategorySpending)

  const handleDateFilter = () => {
    // In a real app, you would fetch filtered category spending from your backend
    console.log("Filtering category spending from", startDate, "to", endDate)
  }

  const totalSpending = categorySpending.reduce((total, category) => total + category.amount, 0)

  return (
    <div className="container max-w-md mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Category Report</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Select Date Range</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <div className="flex-1">
              <label htmlFor="startDate" className="block text-sm font-medium text-muted-foreground mb-1">
                Start Date
              </label>
              <div className="relative">
                <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                <Calendar
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
                  size={18}
                />
              </div>
            </div>
            <div className="flex-1">
              <label htmlFor="endDate" className="block text-sm font-medium text-muted-foreground mb-1">
                End Date
              </label>
              <div className="relative">
                <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                <Calendar
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
                  size={18}
                />
              </div>
            </div>
          </div>
          <Button onClick={handleDateFilter} className="w-full">
            Generate Report
          </Button>
        </CardContent>
      </Card>

      <Tabs defaultValue="table" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="table">Table</TabsTrigger>
          <TabsTrigger value="graph">Graph</TabsTrigger>
        </TabsList>
        <TabsContent value="table">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Category Spending</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {categorySpending.map((category, index) => (
                  <li key={index} className="flex justify-between items-center">
                    <span>{category.category}</span>
                    <span className="font-semibold">${category.amount.toFixed(2)}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-6 pt-4 border-t flex justify-between items-center">
                <span className="font-bold">Total Spending</span>
                <span className="font-bold text-primary">${totalSpending.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="graph">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Spending Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categorySpending}
                      dataKey="amount"
                      nameKey="category"
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      label
                    >
                      {categorySpending.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Category Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categorySpending}>
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="amount" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

