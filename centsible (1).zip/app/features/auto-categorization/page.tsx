import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function AutoCategorizationPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Auto-Categorization</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Our app uses advanced machine learning algorithms to automatically categorize your expenses. This saves you
            time and provides more accurate insights into your spending habits.
          </p>
          <Image
            src="/placeholder.svg?height=300&width=600"
            alt="Auto-Categorization Process"
            width={600}
            height={300}
            className="w-full h-auto mb-4"
          />
          <p>
            The auto-categorization process analyzes the description, amount, and merchant information of each
            transaction to assign the most appropriate category.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="space-y-4">
            <div>
              <dt className="font-semibold">How accurate is the auto-categorization?</dt>
              <dd>
                Our system achieves over 90% accuracy in most cases. You can always manually adjust categories if
                needed.
              </dd>
            </div>
            <div>
              <dt className="font-semibold">Can I create custom categories?</dt>
              <dd>Yes, you can create custom categories, and our system will learn to use them over time.</dd>
            </div>
            <div>
              <dt className="font-semibold">How often is the categorization model updated?</dt>
              <dd>
                We continuously train our model with new data to improve accuracy and adapt to changing spending
                patterns.
              </dd>
            </div>
          </dl>
        </CardContent>
      </Card>
    </div>
  )
}

