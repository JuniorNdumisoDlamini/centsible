import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function SmartAlertsPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Smart Budgeting Alerts</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Our smart budgeting alerts feature uses AI to monitor your spending and notify you of important financial
            events or potential issues before they become problems.
          </p>
          <Image
            src="/placeholder.svg?height=300&width=600"
            alt="Smart Alerts Diagram"
            width={600}
            height={300}
            className="w-full h-auto mb-4"
          />
          <p>
            The diagram above illustrates how our system analyzes your financial data in real-time, predicts potential
            issues, and sends timely alerts to help you stay on track.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Benefits of Smart Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Proactive notifications about upcoming bills or potential overdrafts</li>
            <li>Alerts when you're close to exceeding budget category limits</li>
            <li>Reminders for financial goals and savings targets</li>
            <li>Notifications about unusual spending patterns or potential fraud</li>
            <li>Personalized tips for improving your financial health based on your spending habits</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

