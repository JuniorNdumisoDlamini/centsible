import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function AnomalyDetectionPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Anomaly Detection</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Our anomaly detection feature uses advanced algorithms to identify unusual transactions in your spending
            pattern, helping you catch potential fraud or unintended expenses.
          </p>
          <Image
            src="/placeholder.svg?height=300&width=600"
            alt="Anomaly Detection Flowchart"
            width={600}
            height={300}
            className="w-full h-auto mb-4"
          />
          <p>
            The flowchart above illustrates how our system analyzes each transaction, compares it to your typical
            spending patterns, and flags any suspicious activity for your review.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Benefits of Anomaly Detection</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Early detection of fraudulent activities</li>
            <li>Identification of forgotten subscriptions or recurring charges</li>
            <li>Alerts for unusually large purchases</li>
            <li>Helps maintain accurate budget tracking</li>
            <li>Provides peace of mind and financial security</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

