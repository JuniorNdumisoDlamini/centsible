import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

export default function PersonalizedInsightsPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Personalized Budgeting Insights</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Your Personal Finance Assistant</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Our app provides tailored budgeting insights based on your unique spending patterns and financial goals.
            These insights help you make informed decisions and improve your financial health.
          </p>
          <Image
            src="/placeholder.svg?height=300&width=600"
            alt="Personalized Insights Dashboard"
            width={600}
            height={300}
            className="w-full h-auto mb-4"
          />
          <p>
            The dashboard above shows a sample of the personalized insights you'll receive, including spending trends,
            savings opportunities, and goal progress.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Our Insight Generation Algorithms</CardTitle>
        </CardHeader>
        <CardContent>
          <p>We use a combination of machine learning techniques to generate your personalized insights:</p>
          <ul className="list-disc pl-5 space-y-2 mt-2">
            <li>Pattern recognition to identify spending habits</li>
            <li>Predictive modeling to forecast future expenses</li>
            <li>Clustering algorithms to compare your habits with similar users</li>
            <li>Natural language processing to provide easy-to-understand recommendations</li>
            <li>Reinforcement learning to improve suggestions based on your feedback</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

