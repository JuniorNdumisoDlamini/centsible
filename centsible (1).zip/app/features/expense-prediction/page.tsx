import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "@/components/ui/chart"

const data = [
  { month: "Jan", actual: 4000, predicted: 4200 },
  { month: "Feb", actual: 3000, predicted: 3100 },
  { month: "Mar", actual: 2000, predicted: 2300 },
  { month: "Apr", actual: 2780, predicted: 2600 },
  { month: "May", actual: 1890, predicted: 2100 },
  { month: "Jun", actual: 2390, predicted: 2500 },
  { month: "Jul", actual: 3490, predicted: 3400 },
]

export default function ExpensePredictionPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Expense Prediction</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Our expense prediction feature uses machine learning algorithms to forecast your future expenses based on
            your historical spending patterns and current financial trends.
          </p>
          <div className="h-[300px] w-full mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Actual Expenses" />
                <Line type="monotone" dataKey="predicted" stroke="#82ca9d" name="Predicted Expenses" />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p>
            The graph above shows a comparison between actual expenses and predicted expenses over time, demonstrating
            the accuracy of our prediction model.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>User Testimonial</CardTitle>
        </CardHeader>
        <CardContent>
          <blockquote className="italic border-l-4 border-primary pl-4">
            "The expense prediction feature has been a game-changer for my budgeting. It helps me plan ahead and avoid
            overspending. I've been able to save an extra $200 per month thanks to these insights!"
          </blockquote>
          <p className="mt-2 font-semibold">- Sarah T., Centsible user for 6 months</p>
        </CardContent>
      </Card>
    </div>
  )
}

