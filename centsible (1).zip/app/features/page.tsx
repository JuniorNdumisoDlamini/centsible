import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

const features = [
  { name: "Auto-Categorization", href: "/features/auto-categorization" },
  { name: "Expense Prediction", href: "/features/expense-prediction" },
  { name: "Anomaly Detection", href: "/features/anomaly-detection" },
  { name: "Personalized Budgeting Insights", href: "/features/personalized-insights" },
  { name: "Smart Budgeting Alerts", href: "/features/smart-alerts" },
]

export default function FeaturesPage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Centsible Features</h1>

      <div className="grid gap-6 md:grid-cols-2">
        {features.map((feature) => (
          <Card key={feature.name}>
            <CardHeader>
              <CardTitle>{feature.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <Link href={feature.href} className="text-primary hover:underline">
                Learn more
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

