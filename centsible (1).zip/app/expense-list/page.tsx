"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft, Calendar, Image } from "lucide-react"

// Mock data for expenses
const mockExpenses = [
  { id: 1, date: "2023-06-01", description: "Grocery shopping", amount: 75.5, category: "Groceries", hasPhoto: true },
  { id: 2, date: "2023-06-02", description: "Gas station", amount: 45.0, category: "Transportation", hasPhoto: false },
  { id: 3, date: "2023-06-03", description: "Movie tickets", amount: 30.0, category: "Entertainment", hasPhoto: true },
  // Add more mock expenses as needed
]

export default function ExpenseListPage() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [expenses, setExpenses] = useState(mockExpenses)

  const handleDateFilter = () => {
    // In a real app, you would fetch filtered expenses from your backend
    // For this example, we'll just log the date range
    console.log("Filtering expenses from", startDate, "to", endDate)
  }

  return (
    <div className="container max-w-md mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Expense List</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Filter Expenses</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <div className="flex-1">
              <label htmlFor="startDate" className="block text-sm font-medium text-muted-foreground mb-1">
                Start Date
              </label>
              <div className="relative">
                <Input id="startDate" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                <Calendar
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
                  size={18}
                />
              </div>
            </div>
            <div className="flex-1">
              <label htmlFor="endDate" className="block text-sm font-medium text-muted-foreground mb-1">
                End Date
              </label>
              <div className="relative">
                <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                <Calendar
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
                  size={18}
                />
              </div>
            </div>
          </div>
          <Button onClick={handleDateFilter} className="w-full">
            Apply Filter
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Expenses</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            {expenses.map((expense) => (
              <li key={expense.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold">{expense.description}</p>
                    <p className="text-sm text-muted-foreground">{expense.date}</p>
                  </div>
                  <p className="font-semibold">${expense.amount.toFixed(2)}</p>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm bg-primary/10 text-primary px-2 py-1 rounded-full">{expense.category}</span>
                  {expense.hasPhoto && (
                    <Button variant="ghost" size="sm">
                      <Image className="h-4 w-4 mr-1" />
                      View Photo
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

