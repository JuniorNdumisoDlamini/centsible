"use client"

import { useState, useEffect } from "react"
import { Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type Notification = {
  id: number
  message: string
  type: "info" | "warning" | "success"
  timestamp: Date
}

export function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    // Simulating fetching notifications from an API
    const fetchedNotifications: Notification[] = [
      {
        id: 1,
        message: "You're approaching your budget limit for dining out.",
        type: "warning",
        timestamp: new Date(),
      },
      {
        id: 2,
        message: "Congratulations! You've reached your savings goal.",
        type: "success",
        timestamp: new Date(Date.now() - 86400000),
      },
      {
        id: 3,
        message: "New budgeting tip available. Check it out!",
        type: "info",
        timestamp: new Date(Date.now() - 172800000),
      },
    ]
    setNotifications(fetchedNotifications)
    setUnreadCount(fetchedNotifications.length)
  }, [])

  const handleNotificationClick = (id: number) => {
    // Mark notification as read
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
    setUnreadCount(Math.max(0, unreadCount - 1))
    // Here you would typically handle the notification action, e.g., navigate to a specific page
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
              {unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel>Notifications</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {notifications.length === 0 ? (
          <DropdownMenuItem>No new notifications</DropdownMenuItem>
        ) : (
          notifications.map((notification) => (
            <DropdownMenuItem key={notification.id} onSelect={() => handleNotificationClick(notification.id)}>
              <div className="flex flex-col">
                <span
                  className={`font-medium ${notification.type === "warning" ? "text-yellow-500" : notification.type === "success" ? "text-green-500" : ""}`}
                >
                  {notification.message}
                </span>
                <span className="text-xs text-muted-foreground">{notification.timestamp.toLocaleString()}</span>
              </div>
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

