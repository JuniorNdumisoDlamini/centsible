"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import {
  Settings,
  Plus,
  DollarSign,
  BarChart3,
  FolderOpen,
  Receipt,
  Target,
  Zap,
  Trophy,
  Fingerprint,
  Share2,
  Smartphone,
  Bot,
  Bell,
} from "lucide-react"

export default function ProfileScreen() {
  return (
    <div className="container max-w-md mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Profile</h1>
        <div className="flex items-center space-x-2">
          <Link href="/notifications">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/settings">
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex flex-col items-center mb-8">
        <div className="w-24 h-24 rounded-full bg-primary/10 border-2 border-primary mb-4 overflow-hidden">
          <img src="/placeholder.svg?height=96&width=96" alt="Profile" className="w-full h-full object-cover" />
        </div>
        <h2 className="text-xl font-bold">John Doe</h2>
        <p className="text-muted-foreground">john.doe@example.com</p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Account Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Total Budget</p>
              <p className="text-xl font-bold text-primary">$2,500.00</p>
            </div>
            <div className="text-right">
              <p className="text-muted-foreground text-sm">Spent This Month</p>
              <p className="text-xl font-bold">$1,250.75</p>
            </div>
          </div>
          <Progress value={50} className="h-2" />
          <p className="text-sm text-muted-foreground">50% of monthly budget used</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <ActionButton icon={<Plus className="h-5 w-5" />} label="Add Expense" href="/add-expense" />
            <ActionButton icon={<DollarSign className="h-5 w-5" />} label="Add Income" href="/add-income" />
            <ActionButton icon={<FolderOpen className="h-5 w-5" />} label="Categories" href="/categories" />
            <ActionButton icon={<Target className="h-5 w-5" />} label="Set Goals" href="/budget-goals" />
            <ActionButton icon={<Receipt className="h-5 w-5" />} label="Expenses" href="/expense-list" />
            <ActionButton icon={<BarChart3 className="h-5 w-5" />} label="Reports" href="/category-report" />
            <ActionButton icon={<Zap className="h-5 w-5" />} label="AI Features" href="/features" />
            <ActionButton icon={<Bot className="h-5 w-5" />} label="AI Assistant" href="/ai-assistant" />
            <ActionButton icon={<Trophy className="h-5 w-5" />} label="Challenges" href="/challenges" />
            <ActionButton icon={<Fingerprint className="h-5 w-5" />} label="Security" href="/security" />
            <ActionButton icon={<Share2 className="h-5 w-5" />} label="Social" href="/social" />
            <ActionButton icon={<Smartphone className="h-5 w-5" />} label="Mobile" href="/mobile-features" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function ActionButton({ icon, label, href }: { icon: React.ReactNode; label: string; href: string }) {
  return (
    <Link href={href} className="flex flex-col items-center">
      <Button variant="secondary" size="icon" className="h-12 w-12 rounded-full mb-2">
        {icon}
      </Button>
      <span className="text-xs text-center">{label}</span>
    </Link>
  )
}

