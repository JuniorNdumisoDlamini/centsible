"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function WelcomeScreen() {
  return (
    <div className="flex flex-col items-center justify-between min-h-screen p-6 md:p-8">
      <div className="flex-1"></div>

      <div className="flex flex-col items-center text-center">
        <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center mb-6">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="64"
            height="64"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-primary"
          >
            <path d="M12 1v22" />
            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
          </svg>
        </div>

        <h1 className="text-4xl font-bold text-primary mb-2">Centsible</h1>
        <p className="text-lg text-muted-foreground mb-12">Make every cent count</p>
      </div>

      <div className="w-full max-w-md space-y-4 mb-8">
        <Link href="/login" className="w-full">
          <Button size="lg" className="w-full h-14 text-lg">
            Log In
          </Button>
        </Link>

        <Link href="/register" className="w-full">
          <Button variant="outline" size="lg" className="w-full h-14 text-lg">
            Sign Up
          </Button>
        </Link>
      </div>
    </div>
  )
}

