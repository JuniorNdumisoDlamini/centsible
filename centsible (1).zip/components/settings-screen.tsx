"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"
import { useState } from "react"
import {
  ArrowLeft,
  User,
  Lock,
  CreditCard,
  Moon,
  Bell,
  Fingerprint,
  HelpCircle,
  Info,
  ChevronRight,
  LogOut,
} from "lucide-react"

export default function SettingsScreen() {
  const [darkMode, setDarkMode] = useState(false)
  const [notifications, setNotifications] = useState(true)
  const [biometricAuth, setBiometricAuth] = useState(false)

  return (
    <div className="container max-w-md mx-auto px-4 py-6">
      <div className="flex items-center mb-6">
        <Link href="/profile" className="mr-2">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-sm font-medium text-primary mb-3">Account</h2>
          <div className="space-y-2">
            <SettingsItem icon={<User className="h-5 w-5" />} label="Edit Profile" onClick={() => {}} />
            <SettingsItem icon={<Lock className="h-5 w-5" />} label="Change Password" onClick={() => {}} />
            <SettingsItem icon={<CreditCard className="h-5 w-5" />} label="Payment Methods" onClick={() => {}} />
          </div>
        </div>

        <Separator />

        <div>
          <h2 className="text-sm font-medium text-primary mb-3">App Settings</h2>
          <div className="space-y-2">
            <SettingsToggleItem
              icon={<Moon className="h-5 w-5" />}
              label="Dark Mode"
              checked={darkMode}
              onCheckedChange={setDarkMode}
            />
            <SettingsToggleItem
              icon={<Bell className="h-5 w-5" />}
              label="Notifications"
              checked={notifications}
              onCheckedChange={setNotifications}
            />
            <SettingsToggleItem
              icon={<Fingerprint className="h-5 w-5" />}
              label="Biometric Authentication"
              checked={biometricAuth}
              onCheckedChange={setBiometricAuth}
            />
          </div>
        </div>

        <Separator />

        <div>
          <h2 className="text-sm font-medium text-primary mb-3">Support</h2>
          <div className="space-y-2">
            <SettingsItem icon={<HelpCircle className="h-5 w-5" />} label="Help & Support" onClick={() => {}} />
            <SettingsItem icon={<Info className="h-5 w-5" />} label="About" onClick={() => {}} />
          </div>
        </div>

        <div className="pt-6">
          <Button
            variant="destructive"
            className="w-full"
            onClick={() => {
              window.location.href = "/"
            }}
          >
            <LogOut className="h-5 w-5 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )
}

function SettingsItem({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode
  label: string
  onClick: () => void
}) {
  return (
    <button className="flex items-center justify-between w-full p-3 rounded-md hover:bg-muted" onClick={onClick}>
      <div className="flex items-center">
        <span className="text-muted-foreground mr-3">{icon}</span>
        <span>{label}</span>
      </div>
      <ChevronRight className="h-5 w-5 text-muted-foreground" />
    </button>
  )
}

function SettingsToggleItem({
  icon,
  label,
  checked,
  onCheckedChange,
}: {
  icon: React.ReactNode
  label: string
  checked: boolean
  onCheckedChange: (checked: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between w-full p-3 rounded-md">
      <div className="flex items-center">
        <span className="text-muted-foreground mr-3">{icon}</span>
        <span>{label}</span>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  )
}

