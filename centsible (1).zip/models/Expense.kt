package com.example.centsible.models

import java.util.Date

data class Expense(
    val id: Int,
    val amount: Double,
    val description: String,
    val categoryId: Int,
    val date: Date,
    val createdAt: Date
)

