package com.example.centsible.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.centsible.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile") },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("John Doe", style = MaterialTheme.typography.headlineMedium)
            Text("john.doe@example.com", style = MaterialTheme.typography.bodyLarge)

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { navController.navigate(Screen.AddExpense.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Expense")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.AddIncome.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Income")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.Categories.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Categories")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.BudgetGoals.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Budget Goals")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.ExpenseList.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Expense List")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.CategoryReport.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Category Report")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.AIAssistant.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("AI Assistant")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate(Screen.BankingIntegration.route) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Connect Banks")
            }
        }
    }
}

