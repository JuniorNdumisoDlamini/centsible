package com.example.centsible.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

data class CategoryExpense(val category: String, val amount: Double)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryReportScreen(navController: NavController) {
    val categoryExpenses = remember {
        listOf(
            CategoryExpense("Food", 250.0),
            CategoryExpense("Transportation", 150.0),
            CategoryExpense("Entertainment", 100.0),
            CategoryExpense("Utilities", 200.0)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Category Report") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text("Total Expenses by Category", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn {
                items(categoryExpenses) { categoryExpense ->
                    CategoryExpenseItem(categoryExpense)
                }
            }
        }
    }
}

@Composable
fun CategoryExpenseItem(categoryExpense: CategoryExpense) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
        ) {
            Text(text = categoryExpense.category, style = MaterialTheme.typography.titleMedium)
            Text(
                text = "$${categoryExpense.amount}",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Green
            )
        }
    }
}

