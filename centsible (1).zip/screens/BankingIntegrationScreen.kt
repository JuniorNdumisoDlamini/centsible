package com.example.centsible.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BankingIntegrationScreen(navController: NavController) {
    var selectedBanks by remember { mutableStateOf(setOf<String>()) }
    val availableBanks = listOf("Bank A", "Bank B", "Bank C", "Bank D")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Banking Integration") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "Connect Your Banks",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Text(
                text = "Select the banks you'd like to connect to Centsible:",
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyColumn(
                modifier = Modifier.weight(1f)
            ) {
                items(availableBanks) { bank ->
                    BankItem(
                        bankName = bank,
                        isSelected = selectedBanks.contains(bank),
                        onSelectionChanged = { isSelected ->
                            selectedBanks = if (isSelected) {
                                selectedBanks + bank
                            } else {
                                selectedBanks - bank
                            }
                        }
                    )
                }
            }

            Button(
                onClick = {
                    // TODO: Implement bank connection logic
                    println("Connecting to banks: $selectedBanks")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Text("Connect Selected Banks")
            }
        }
    }
}

@Composable
fun BankItem(
    bankName: String,
    isSelected: Boolean,
    onSelectionChanged: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = isSelected,
            onCheckedChange = { onSelectionChanged(it) }
        )
        Text(
            text = bankName,
            modifier = Modifier.padding(start = 16.dp)
        )
    }
}

