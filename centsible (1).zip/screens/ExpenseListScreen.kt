package com.example.centsible.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

data class Expense(val amount: Double, val description: String, val category: String, val date: Date)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseListScreen(navController: NavController) {
    val expenses = remember {
        mutableStateListOf(
            Expense(50.0, "Groceries", "Food", Date()),
            Expense(30.0, "Gas", "Transportation", Date(System.currentTimeMillis() - 86400000)),
            Expense(20.0, "Movie tickets", "Entertainment", Date(System.currentTimeMillis() - 172800000))
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Expense List") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            items(expenses) { expense ->
                ExpenseItem(expense)
            }
        }
    }
}

@Composable
fun ExpenseItem(expense: Expense) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
        ) {
            Text(text = expense.description, style = MaterialTheme.typography.titleMedium)
            Text(text = "Amount: $${expense.amount}", style = MaterialTheme.typography.bodyMedium)
            Text(text = "Category: ${expense.category}", style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "Date: ${SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(expense.date)}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

