package com.example.centsible.utils

import android.content.Context
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage
import com.example.centsible.BuildConfig

object SupabaseClient {
    private var client: SupabaseClient? = null

    fun initialize(context: Context): SupabaseClient {
        if (client == null) {
            client = createSupabaseClient(
                supabaseUrl = BuildConfig.SUPABASE_URL,
                supabaseKey = BuildConfig.SUPABASE_ANON_KEY
            ) {
                install(Auth)
                install(Postgrest)
                install(Storage)
            }
        }
        return client!!
    }

    fun getClient(): SupabaseClient {
        return client ?: throw IllegalStateException("Supabase client not initialized")
    }
}

